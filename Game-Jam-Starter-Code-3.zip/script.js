/* VARIABLES */
//screen 
let screen = 0;
//Font
let font;
//Lore
let lore;
//left or right
let player, walls, church, playerImg;
//Celestial riddles
let starC, mutedC, cherryC, butterC, catC, bookC;
let symbols = [];
let sName = ['starC', 'mutedC', 'cherryC', 'butterC', 'catC', 'bookC'];
let order = [1,3,4];
let current = 0;
let win  = true;
let bookback;
let pSymbols = [];

//enter
let enterButton, next;

//autonmy maze
/* VARIABLES */
let item1, item2, item3, enemy1, enemy2, enemy3, items, enemeies, wall1, wall2, wall3, wall4, wall5, wall6, wall7, wall8, wall9, wall10, wall11, wall12;
let score = 0;

let offset = 1000; // to move the maze walls until they're needed
let mazeStart = true; // used to move the walls back into place once the maze section starts

let photo;

/* PRELOAD LOADS FILES */
function preload(){
  //photo
  photo = loadImage('assets/photo.png');
  //font
  font = loadFont('assets/font.ttf');
  //lore initializee
  lore = loadImage('assets/lore.png');
  //otto
  otto = loadImage("assets/otto.png");
  //juliea 
  juliea = loadImage("assets/juliea.png");
  //vera
  vera = loadImage("assets/vera.png");
  //sara
  sara = loadImage("assets/sara.png");
  //annora
  annora = loadImage("assets/annora.png");
  //briar
  briar = loadImage("assets/briar.png")
;
  //church
  church = loadImage("assets/church.png");
  //player
  playerImg = loadImage("assets/player.png");
  // celestial riddles 
  bookback = loadImage('assets/book.png');
  image[0] = loadImage('assets/star.png');
  image[1] = loadImage('assets/lips.png');
  image[2] = loadImage('assets/cherry.png');
  image[3] = loadImage('assets/butter.png');
  image[4] = loadImage('assets/cat.png');
  image[5] = loadImage('assets/bookC.png');

}

/* SETUP RUNS ONCE */
function setup() {
  createCanvas(400,400);
  textFont(font);
  //photo sprite
  photo = new Sprite(photo, -200, -200);
  //set up button sprites lol
  //enter button
  enterButton = new Sprite(200, 200, 140, 50);
  enterButton.text = "Enter";
  enterButton.color = "white";
  enterButton.textSize = 25;

  next = new Sprite(-200, -200, 100, 50);
  next.text = "Next";
  next.color = "white";
  next.textSize = 25;

  //player
  player = new Sprite(-200, -70, -40, -40);
  player.image = playerImg;
  player.scale = 0.1;
  player.rotationLock = true;

  //walls
  walls = new Group();
  walls.color = color("white");
  walls.collider = "k";

  // new wall1.Sprite(200, 5, 400, 5);
  //  new wall2.Sprite(200, 395, 400, 5);
  // new wall3.Sprite(5, 240, 5, 315);
  // new wall4.Sprite(395, 240, 5, 315);

  // just so I can run the code
  new walls.Sprite(200 + 100 + offset, 5, 400, 5);
   new walls.Sprite(200 + 100 + offset, 395, 400, 5);
  new walls.Sprite(5 + 100 + offset, 240, 5, 315);
  new walls.Sprite(395 + 100 + offset, 240, 5, 315);

  //celestial riddles
  starC = new Sprite(image[0],-100,-100);
  starC.scale = 0.1;
  starC.collider = "s";
  mutedC = new Sprite(image[1],-200,-100);
  mutedC.scale = 0.1;
  mutedC.collider = "s";
  cherryC = new Sprite(image[2],-300,-100);
  cherryC.scale = 0.1;
  cherryC.collider = "s";
  butterC = new Sprite(image[3],-100,-200);
  butterC.scale = 0.1;
  butterC.collider = "s";
  catC = new Sprite(image[4],-200,-200);
  catC.scale = 0.2;
  catC.collider = "s";
  bookC = new Sprite(image[5],-300,-200);
  bookC.scale = 0.1;
  bookC.collider = "s";

  //autonmy maze
  items = new Group;
  items.collider = "k";
  items.rotationLock = "true";
  items.textSize = 8;
  items.text = "placeholder";
  items.color = "white";

  item1 = new items.Sprite(-40, -40, 40, 40);
  item2 = new items.Sprite(-130, -40, 40, 40);
  item3 = new items.Sprite(-300, -345, 40, 40);

  enemeies = new Group;
  enemeies.collider = "k";
  enemeies.rotationLock = "true";

   //  new wall5.Sprite(160, 10, 300, 5,);
   //  //left
   // new wall6.Sprite(10, height/2, 5, height - 15); 
   //  //right
   //  new walls7.Sprite(width/2 + 35, 390, 325, 5);
   //  //bottom
   //  new wall8.Sprite(395, 200, 5, 380);
   //  new wall9.Sprite(310, 110, 5, 200);
   //  new wall10.Sprite(230, 268, 5, 250);
   //  new wall11.Sprite(100, 335, 5, 100);
   //  new wall12.Sprite(100, 110, 5, 200);

  new walls.Sprite(160 + offset, 10, 300, 5,);
    //left
   new walls.Sprite(10 + offset, height/2, 5, height - 15); 
    //right
    new walls.Sprite(width/2 + 35 + offset, 390, 325, 5);
    //bottom
    new walls.Sprite(395 + offset, 200, 5, 380);
    new walls.Sprite(310 + offset, 110, 5, 200);
    new walls.Sprite(230 + offset, 268, 5, 250);
    new walls.Sprite(100 + offset, 335, 5, 100);
    new walls.Sprite(100 + offset, 110, 5, 200);
  
}

/* DRAW LOOP REPEATS */
function draw() {
  background(0);

  if (screen == 0) {
    background(lore);
    if (enterButton.mouse.presses()) {
      screen = 1;
    }
  } else if (screen == 1) {
    intro();
    fill("white");
    textSize(30);
    textAlign(CENTER);
    text("The Legend of The Discovered\n is more than a myth...", 200, 150);
    if (next.mouse.presses()) {
      screen = 2;
    }
  } else if (screen == 2) {
    background(0);
    history1();
    fill("black");
    textSize(15);
    text("It all began with a young woman from Kwesi. Who had\n the marking of the Gods on her wrist and a birthmark on\n her right cheek. She was raised in the solstice church\n honing her powers.", 200, 300);
    if (next.mouse.presses()) {
      screen = 3;
    }
  } else if (screen == 3) {
    background(0);
    history1();
    fill("black");
    textSize(15);
    text("As the years went by she did not age and those who were\n close to her passed. She felt alone. People around her saw\n her as an extension of her magic instead of a person\n Until she got a vision that she would not be alone anymore.", 200, 300);
    if (next.mouse.presses()) {
      screen = 4;
    }
  } else if (screen == 4) {
    background(0);
    history2();
    fill("black");
    textSize(15);
    text("Juliea, similarly to Otto, had the sign of the gods on her\n wrist and a birthmark on both of her cheeks discovered on\n her 18th. The original found her in Celia, surrounded by\n marigolds and brought her to Solstice.", 200, 300);
    if (next.mouse.presses()) {
      screen = 5;
    }
  } else if (screen == 5) {
    background(0);
    history2();
    fill("black");
    textSize(15);
    text("It was quiet for years, generations passed before another\n discovery occured But this time, they were different. The\n birthmark on their wrist was different, yet the birthmark\n on their cheek remained", 200, 300);
    if (next.mouse.presses()) {
      screen = 6;
    }
  } else if (screen == 6) {
    background(0);
    history3();
    fill("black");
    textSize(15);
    text("Vera was born in Vy, but had blood both of the Vy and\n Aasta people. Although more hyperactive than the other\n two, they balanced the other two out well. Very\n quickly they noticed that their magic was different as well...", 200, 290);
    if (next.mouse.presses()) {
      screen = 7;
    }
  } else if (screen == 7) {
    background(0);
    history4();
    fill("black");
    textSize(15);
    text("Unlike the other three, with many years between their\n discovery, Sara was discovered in Aurora a couple years\n after Vera. She had the same marking and her birthmark on her left cheek. They\n became very close.", 200, 290);
    if (next.mouse.presses()) {
      screen = 8;
    }
  } else if (screen == 8) {
    background(0);
    history3();
    fill("black");
    textSize(15);
    text(" Now having a companion, Vera moved out solerias to Valeria\n to continue on with their studies. With the new discovery\n that the difference lay in what their magic represented.\n Otto and Juliea magic focused on the world around them,\n while Vera and Sara were enhancers to individuals.", 200, 290);
    if (next.mouse.presses()) {
      screen = 9;
    }
  } else if (screen == 9) {
    background(0);
    history5();
    fill("black");
    textSize(15);
    text("Annora was discovered a year after Sara. Her birthmark \nmatches the originals and her birthmark on her right cheek.\n When Otto and Juliea met her for the first time. Their\n symbols shined a bright silver and remained that color-\n symbolizing that the celestial branch was completed. ", 200, 290);
    if (next.mouse.presses()) {
      screen = 10;
    }
  } else if (screen == 10) {
    history6();
    fill("black");
    textSize(14);
    text("They were expecting a new discovery soon after, but a vision\n never came and neither did that feeling. Tension grew between\n Vera and Sara. Although they were very close, they were also very competitive.\n A silly game grew into a war that neither knew why it began\n in the first place. This 100 year war known as ‘Sleow’ ", 200, 290);
    if (next.mouse.presses()) {
      screen = 11;
    }
  } else if (screen == 11) {
    history7();
    fill("black");
    textSize(14);
    text("The others found it amusing. Otto, the referee, granted benefits\n to both sides as a way to stir the pot. Annora allied with Sara,\n giving aid when they could but would also visit Vera confusing\n them on which side of the war Annora was on. Juliea minded\n her business, and aided with crops.", 200, 155);
    if (next.mouse.presses()) {
      screen = 12;
    }
  } else if (screen == 12) {
    history8();
    fill("black");
    textSize(14);
    text("Around the 50 year mark, another was discovered; Briar. It\n was the only pause in the war when they all went to greet her.\n They had the same markings as Vera and Sara and their\n birthmark laid on their left cheek. Their markings glowed silver\n symbolizing that the Autonomy group was completed.\n  Briar aided Vera, becoming like a younger sibling to them.", 200, 285);
    if (next.mouse.presses()) {
      screen = 13;
    }
  } else if (screen == 13) {
    history7();
    fill("black");
    textSize(14);
    text("Over time they lost interest in the war, but Vera and Sara\n wanted a definitive winner. Otto gave them a last challenge\n and Sara was the victor. Vera and Sara became closer and like\n they were once they decided to team up. After traveling the world\n and many millenia apart in their own churches, they decided\n to go home back to Solstice.", 200, 155);
    if (next.mouse.presses()) {
      screen = 14;
    }
  } else if (screen == 14) {
    history7();
    fill("black");
    textSize(14);
    text("The people began to forget about them and those who knew of\n them feared them. In a night full of disdain, they were forced\n and burned into stained glass. The last vision granted to the\n six of them was that they were going to be freed\n by the next discovery.", 200, 155);
    if (next.mouse.presses()) {
      screen = 15;
    }
  } else if (screen == 15) {
    history7();
    player.pos = {x: 200, y: 70};

    fill("black");
    textSize(14);
    text("Now as you stand in front of the beautiful window in Solstice\n a marking shows upon your arm, one that is unique and not\n of the celestials nor the autonomy. Here is where your journey\n begins. It has been a millennia since they became just a legend\n and it’s time for you to set them free.\n Do you go left or right?", 200, 155);
    if (next.mouse.presses()) {
      screen = 16;
    }
  } else if (screen == 16) {
    background(0);
    next.visible = false;
    hallway();

    // Move the player
    if (kb.pressing("left")) {
      player.vel.x = -2;
    } else if (kb.pressing("right")) {
      player.vel.x = 2;
    } else if (kb.pressing("up")) {
      player.vel.y = -2;
    } else if (kb.pressing("down")) {
      player.vel.y = 2;
    } else {
      player.vel.x = 0;
      player.vel.y = 0;
    }

    // Player cannot go above maze
    if (player.y < 20) {
      player.y = 20;
    }

    // Player wins
    if (player.x < 5) {
      screen = 17;
    }
  } else if (screen == 17) {
    celestialR();
  }

  if (player.x > 395) {
    screen = 18;
  } else if (screen == 18) {
    autonomyM();
  }
}

  //if then starting game left or right
  //left is automny
  //right is celestial

/* FUNCTIONS */
//HISTORY
function intro(){
  background(0);
  enterButton.visible = false;
  next.pos = {x: 315, y: 350};
  screen = 1;
}
function history1(){
  background(otto);
  fill("white");
  rect(15, 270, 370, 100);
  
  next.pos = {x: 315, y: 100};
  next.h = 45;
  next.w = 100;

}
function history2(){
  background(juliea);
  fill("white");
  rect(15, 270, 370, 100);

  next.pos = {x: 60, y: 160};
  next.h = 45;
  next.w = 100;

}
function history3(){
  background(vera);
  fill("white");
  rect(15, 270, 370, 100);

  next.pos = {x: 60, y: 160};
  next.h = 45;
  next.w = 100;

}
function history4(){
  background(sara);
  fill("white");
  rect(15, 270, 370, 100);

  next.pos = {x: 60, y: 160};
  next.h = 45;
  next.w = 100;

}
function history5(){
  background(annora);
  fill("white");
  rect(15, 270, 370, 100);

  next.pos = {x: 60, y: 160};
  next.h = 45;
  next.w = 100;

}
function history6(){
  background(0);
  image(vera, 0, 0, 215, 280);
  image(sara, 180, 0, 220, 300);
 fill("white");
  rect(15, 270, 370, 100);

  next.pos = {x: 220, y: 250};
  next.h = 45;
  next.w = 100;

}
function history7(){
  background(lore);
   fill("white");
    rect(15, 140, 370, 115);

    next.pos = {x: 290, y: 255};
    next.h = 25;
    next.w = 100;
}
function history8(){
  background(briar);
  fill("white");
  rect(15, 270, 375, 115);

  next.pos = {x: 60, y: 160};
  next.h = 45;
  next.w = 100;
}
function hallway(){
  background(church);
 
}
function celestialR(){
  background(bookback);
  screen = 17;

  starC.pos = {x:97,y:75};
  mutedC.pos = {x:200,y:120};
  cherryC.pos = {x:300,y:75};
  butterC.pos = {x:100,y:200};
  catC.pos = {x:200,y:360};
  bookC.pos = {x:300,y:220};


  if(starC.mouse.presses()){
    pSymbols.push(0);
    print(pSymbols);
  }
  if(mutedC.mouse.presses()){
    pSymbols.push(1);
    print(pSymbols);
  }
  if(cherryC.mouse.presses()){
    pSymbols.push(2);
    print(pSymbols);
  }
  if(butterC.mouse.presses()){
    pSymbols.push(3);
    print(pSymbols);
  }
  if(catC.mouse.presses()){
    pSymbols.push(4);
    print(pSymbols);
  }
  if(bookC.mouse.presses()){
    pSymbols.push(5);
    print(pSymbols);
  }
  win = true;
  for(let i = 0; i < order.length; i++){
    if (pSymbols[i] !== order[i]){
      print("incorect");
      win = false;
      break;
    }
  }
  if (win && pSymbols.length === order.length){
    print("you win");
}
}
//All of this is riddle based, inspired by the individuals and things that we have said. Left is going to be a maze, while right is going to be a drag and drop game
function autonomyM(){
  background(0);
  player.pos = {x: 200, y: 70};

  background("black");
  item1.pos = {x:40,y:40};
  item2.pos = {x:130,y:40};
  item3.pos = {x:300,y:345};

  // move the walls of the maze into position at the start of mini game
  // sorry for the random for loop, but moving everything by hand made me want to cry😭
  if (mazeStart) {
    for (let i = 0; i < walls.length; i++) {
      walls[i].x -= offset;
    }
    mazeStart = false;
  }



  //Move the player
  if (kb.pressing("left")) {
    player.vel.x = -3;
  } else if (kb.pressing("right")) {
    player.vel.x = 3;
  } else if (kb.pressing("up")) {
    player.vel.y = -3;
  } else if (kb.pressing("down")) {
    player.vel.y = 3;
  } else {
    player.vel.x = 0;
    player.vel.y = 0;
  }

  //collect the items
  if (player.collides(item1)) {
    score++;
    item1.pos = {x:-400,y:-400};
  }
  else if (player.collides(item2)) {
    score++;
    item2.pos = {x:-400,y:-400};
  }
  else if (player.collides(item3)) {
    score++;
    item3.pos = {x:-400,y:-400};
  }

  //Player cannot go above maze
  if (player.y < 20) {
    player.y = 20;
  }

  // Player wins
  if (player.y > 380 && score == 3) {
    print("win");
    player.vel.x = 0;
    player.vel.y = 0;
    background = "black";
    fill("white");
    Text("you win", 200, 200);
  }
}
